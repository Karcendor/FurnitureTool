using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using FurnetureTool.Models;
using FurnetureTool.Models.FilterViewModel;
using Microsoft.EntityFrameworkCore;

namespace FurnetureTool.Controllers;

public class ShopController : Controller
{

        ApplicationContext db;
        public ShopController(ApplicationContext context)
            {
                db = context;
            }
        [Route("Shop")]
        public IActionResult Shop()
            {
            return View(db.Specifications.ToList());

            }
        [Route("Cart")]

    [HttpPost]
    public IActionResult ProductCart(int Id ,int qty)
    {
        Cart cart = new Cart();
        Product product = db.Specifications.FirstOrDefault(p=>p.Id == Id);
        if(product != null)
        {
            cart.AddCart(product,1);
        }
        return View("AddCart",product);
    }
    /*[Route("Cart")]
    public IActionResult Cart()
    {
        return View();
    }*/
    [Route("Shop/{id?}")]
    public IActionResult ProductCart(ProductViewModel user,int? id)
    {
        var product  = db.Specifications
                            .Where(c => c.Id == id)
                            .Select(c => new
                            {
                                name = c.Name,
                                price = c.Price,
                                brand = c.Brand,
                                Image = c.ImageOne
                            });
        
        Product products = new Product();//{Id = user.Id,Name = user.Name,Price = user.Price};
        foreach (var item in product)
        {
            products.Brand = item.brand;
            products.Price = item.price;
            products.ImageOne = item.Image;
        }
        return View(products);
    }
}