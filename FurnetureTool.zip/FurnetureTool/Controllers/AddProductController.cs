using FurnetureTool.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FurnetureTool.Controllers;

public class AddProductController : Controller
{
    ApplicationContext db;
    public AddProductController(ApplicationContext context)
    {
        db = context;
    }
    [Route("Products")]
    public async Task<IActionResult> Products()
        {
            return View(await db.Specifications.ToListAsync());
        }
        [Route("CreateProduct")]
        public IActionResult CreateProduct()
        {
            return View();
        }
        [HttpPost]
        public IActionResult CreateProducts(ProductViewModel user)
        {
            Product product = new Product{Id = user.Id,Name = user.Name,Brand = user.Brand,Price = user.Price};
            if(user.ImageOne != null)
            {
                byte[] imageData = null;
                using (var binaryReader = new BinaryReader(user.ImageOne.OpenReadStream()))
                {
                    imageData = binaryReader.ReadBytes((int)user.ImageOne.Length);
                }
                product.ImageOne = imageData;
            }
            db.Specifications.Add(product);
            db.SaveChanges();
            return RedirectToAction("Products");
        }
}