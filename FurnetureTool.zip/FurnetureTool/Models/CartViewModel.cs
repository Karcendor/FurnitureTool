namespace FurnetureTool.Models;
public class CartModel
    {
        public int Qty {get;set;}
        public Product Product {get;set;}
    
    }

public class Cart
{
    public  List<CartModel> productCart = new List<CartModel>();

    public void AddCart(Product product,int qty)
    {
        CartModel line = productCart
                .Where(g => g.Product.Id == product.Id)
                .FirstOrDefault();
        if(line == null)
        {
            productCart.Add(new CartModel
            {
                Product = product,
                Qty = qty
            
            });
        }
        else
        {
            line.Qty += qty;
        }
    }
    public void RemoveCart(Product product)
    {
        productCart.RemoveAll(e => e.Product.Id ==product.Id);
    }

    public void ClearCart()
    {
        productCart.Clear();
    }

    public double CartSum()
    {
        return productCart.Sum(e => e.Product.Price * e.Qty);
    }
    public double CartCountProduct()
    {
        return productCart.Count();
    }
}
public class CartViewModel
    {
        public int Qty {get;set;}
        public Product Product {get;set;}
    
    }

