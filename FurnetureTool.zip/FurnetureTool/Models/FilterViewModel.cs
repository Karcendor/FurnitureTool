namespace FurnetureTool.Models;

public class FilterViewModel
{
    public record class Category(string Name);
    
    public IEnumerable<Category> ProductCategories{get;set;} = new List<Category>();
    public IEnumerable<Category> ProductFilter{get;set;} = new List<Category>();
}