using Microsoft.EntityFrameworkCore;

namespace FurnetureTool.Models;


public class Product
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string Brand { get; set; } 

    public int Price{get;set;}
    public byte[] ImageOne {get;set;}


}
public class ApplicationContext : DbContext
{
    public DbSet<Product> Specifications { get; set; }
    public ApplicationContext()
        {
            Database.OpenConnection();
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseMySql(
                "server=localhost;database=SpecificationProduct;;uid=root;pwd=Amagamam;;", 
                new MySqlServerVersion(new Version(8, 0, 29))
            );
        }
}
public class ProductViewModel
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string Brand { get; set; } 
    public int Price{get;set;}
    public IFormFile ImageOne { get; set; }
}

