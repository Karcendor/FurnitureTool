using FurnetureTool.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Tests
{
    [TestClass]
    public class CartTest
    {
        [TestMethod]
        public void TestAddItemCart()
        {
            Product product1 = new Product{Id = 1 ,Name = "Bebra",Price = 500};
            Cart cart = new Cart();

            cart.AddCart(product1,1);
            List<CartModel> result = cart.productCart.ToList();

            Assert.AreEqual(result.Count(),1);
            Assert.AreEqual(result[0].Product,product1);
        }


        [TestMethod]
        public void TestPrice()
        {
            Product product1 = new Product{Id = 1 ,Name = "Bebra",Price = 500};
            Product product2 = new Product{Id = 2 ,Name = "Dildo",Price = 700};
            Product product3 = new Product{Id = 3 ,Name = "Dora", Price = 1200};

            Cart cart = new Cart();
            cart.AddCart(product1,1);
            cart.AddCart(product2,1);
            cart.AddCart(product3,1);

            double Sum = cart.CartSum();

            Assert.AreEqual(Sum,2400);
        }
        [TestMethod]
        public void TestCount()
        {
            Product product1 = new Product{Id = 1 ,Name = "Bebra",Price = 500};
            Product product2 = new Product{Id = 2 ,Name = "Dildo",Price = 700};
            Product product3 = new Product{Id = 3 ,Name = "Dora", Price = 1200};

            Cart cart = new Cart();
            cart.AddCart(product1,1);
            cart.AddCart(product2,1);
            cart.AddCart(product3,1);

            double Cout = cart.CartCountProduct();

            Assert.AreEqual(Cout,3);
        }
        [TestMethod]
        public void RemovCartTest()
        {
            Product product1 = new Product{Id = 1 ,Name = "Bebra",Price = 500};
            Product product2 = new Product{Id = 2 ,Name = "Dildo",Price = 700};
            Product product3 = new Product{Id = 3 ,Name = "Dora", Price = 1200};

            Cart cart = new Cart();
            cart.AddCart(product1,1);
            cart.AddCart(product2,1);
            cart.AddCart(product3,1);

            cart.RemoveCart(product2);

            Assert.AreEqual(cart.productCart.Where(c => c.Product == product2).Count(),0);
            Assert.AreEqual(cart.productCart.Count(),2);


        }
    }
    
}