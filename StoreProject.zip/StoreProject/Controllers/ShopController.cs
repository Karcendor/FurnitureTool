using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using StoreProject.Models;
using Microsoft.EntityFrameworkCore;
using System.Web;
using System.Text.Json;

namespace StoreProject.Controllers;

public class ShopController:Controller
{
    ApplicationContext db;
    public ShopController(ApplicationContext context)
    {
        db = context;
    }

    [Route("Shop")]
    public IActionResult Shop()
    {
        return View(db.Specifications.ToList());
    }
    [Route("Shop/{id?}")]
    public IActionResult SingleProduct(ProductViewModel user,int? id)
    {
        var product  = db.Specifications
                            .Where(c => c.Id == id)
                            .Select(c => new
                            {
                                name = c.Name,
                                price = c.Price,
                                brand = c.Brand,
                                //Image = c.ImageOne
                            });
        
        ProductViewModel products = new ProductViewModel();//{Id = user.Id,Name = user.Name,Price = user.Price};
        foreach (var item in product)
        {
            products.Brand = item.brand;
            products.Price = item.price;
            //products.ImageOne = item.Image;
        }
        return View(products);
    }
    

}
