using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using StoreProject.Models;

namespace StoreProject.Controllers;
public class CartController : Controller
{
    ApplicationContext db;
    public CartController(ApplicationContext context)
    {
        db = context;
    }
    [Route("Cart")]
    public ViewResult Cart()
    {
        
        return View(new CartViewModel
        {
            OperationCart = GetCart()
        });
    }

    public IActionResult AddToCart(int id)
    {
        ProductViewModel product = db.Specifications
                                        .FirstOrDefault(g => g.Id == id);
        if(product != null)
        {
            CartModel cart = new CartModel{
            Product = product,
            NumberProduct = 1
            };
            GetCart().AddToCart(cart);
        }
        return  Redirect("/Cart");
    }
    public OperationCart GetCart()
    {
        OperationCart operationCart = HttpContext.Session.Get<OperationCart>("OperationCart");
        if (operationCart == null)
        {
            operationCart = new OperationCart();
            HttpContext.Session.Set<OperationCart>( "OperationCart" , operationCart);
        }
        
        foreach (var item in operationCart.Lines)
        {
            Console.WriteLine(item.Product.Id);
        }
        return operationCart;
    }
}
