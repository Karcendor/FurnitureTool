using Microsoft.EntityFrameworkCore;
using StoreProject.Models;

public class ApplicationContext : DbContext
{
    public DbSet<ProductViewModel> Specifications { get; set; }
    public ApplicationContext()
        {
            Database.OpenConnection();
        }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseMySql(
                "server=localhost;database=SpecificationProduct;;uid=root;pwd=Amagamam;;", 
                new MySqlServerVersion(new Version(8, 0, 29))
            );
        }
}