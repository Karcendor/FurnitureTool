
using System.Text.Json;
using Microsoft.AspNetCore.Mvc;

namespace StoreProject.Models;
public class ProductViewModel
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string Brand { get; set; } 
    public int Price{get;set;}
    //public IFormFile ImageOne { get; set; }
}
public class CartModel
{
    public ProductViewModel Product{get ; set; }

    public int NumberProduct {get ; set ;}
}

public class CartViewModel
{
    public OperationCart OperationCart {get;set;}
}

public class OperationCart
{
    string ShoppingCartId { get; set; }

    private List<CartModel> Cart = new List<CartModel>();
    public void AddToCart(CartModel CartModel)
    {
        Cart.Add(CartModel);
    }
    public IEnumerable<CartModel> Lines
    {
            get { return Cart; }
    }
}

public static class SessionExtensions
    {
    public static void Set<T>(this ISession session, string key, T value)
        {
            session.SetString(key, JsonSerializer.Serialize<T>(value));
        }
 
    public static T Get<T>(this ISession session, string key)
        {
        var value = session.GetString(key);
        return value == null ? default(T) : JsonSerializer.Deserialize<T>(value);
        }
    }
